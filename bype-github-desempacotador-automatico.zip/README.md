# Desempacotador automático — Bype Eleições

Este pacote configura o GitHub Actions para extrair `bype-eleicoes.zip` automaticamente no próprio repositório.

## Instalação

1. Extraia este pacote no seu computador.
2. Envie para a raiz do seu repositório GitHub a pasta `.github` e o arquivo `bype-eleicoes.zip`.
3. Faça um `commit` e `push`.
4. No GitHub, abra a aba **Actions** e acompanhe a execução **Desempacotar projeto Bype**.

Quando terminar, os arquivos estarão na pasta `bype-eleicoes/` do repositório, com as pastas e formatos originais.

Também é possível executar manualmente em **Actions > Desempacotar projeto Bype > Run workflow**.

## Permissão necessária

Em **Settings > Actions > General > Workflow permissions**, habilite **Read and write permissions** para permitir que o workflow grave os arquivos extraídos no repositório.

O workflow é acionado quando `bype-eleicoes.zip` é enviado ou atualizado. Ele não altera nem converte os arquivos originais do ZIP.
